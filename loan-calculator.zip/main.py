import tkinter as tk
from tkinter import messagebox

def calculate_loan():
    try:
        principal = float(entry_principal.get())
        interest_rate = float(entry_interest_rate.get()) / 100
        loan_term = int(entry_loan_term.get())

        monthly_interest_rate = interest_rate / 12
        num_payments = loan_term * 12

        monthly_payment = (principal * monthly_interest_rate) / (1 - (1 + monthly_interest_rate) ** -num_payments)
        total_payment = monthly_payment * num_payments

        result_label.config(text=f"Monthly Payment: ₹{monthly_payment:.2f}\nTotal Payment: ₹{total_payment:.2f}")

    except ValueError:
        messagebox.showerror("Error", "Please enter valid numerical values.")

# Create main window
root = tk.Tk()
root.title("Flood-Loan Calculator")
root.geometry("400x300")  # Set a larger window size

# Set background color to baby pink
root.configure(bg="#FFD1DC")

# Create and place widgets with color and font adjustments
label_principal = tk.Label(root, text="Loan Amount (₹):", bg="#FFD1DC", font=("Helvetica", 12))
label_principal.grid(row=0, column=0, padx=10, pady=10, sticky="w")

entry_principal = tk.Entry(root, font=("Helvetica", 12))
entry_principal.grid(row=0, column=1, padx=10, pady=10)

label_interest_rate = tk.Label(root, text="Annual Interest Rate (%):", bg="#FFD1DC", font=("Helvetica", 12))
label_interest_rate.grid(row=1, column=0, padx=10, pady=10, sticky="w")

entry_interest_rate = tk.Entry(root, font=("Helvetica", 12))
entry_interest_rate.grid(row=1, column=1, padx=10, pady=10)

label_loan_term = tk.Label(root, text="Loan Term (years):", bg="#FFD1DC", font=("Helvetica", 12))
label_loan_term.grid(row=2, column=0, padx=10, pady=10, sticky="w")

entry_loan_term = tk.Entry(root, font=("Helvetica", 12))
entry_loan_term.grid(row=2, column=1, padx=10, pady=10)

calculate_button = tk.Button(root, text="Calculate", command=calculate_loan, font=("Helvetica", 12), bg="#4CAF50", fg="white")
calculate_button.grid(row=3, column=0, columnspan=2, pady=10)

result_label = tk.Label(root, text="", bg="#FFD1DC", font=("Helvetica", 14), justify="left")
result_label.grid(row=4, column=0, columnspan=2, padx=10, pady=10)

# Run the application
root.mainloop()


